def print_from_function():
    print("Function works!!!")
